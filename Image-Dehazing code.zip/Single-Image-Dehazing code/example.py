import cv2
import image_dehazer

if __name__ == "__main__":

    HImg = cv2.imread('Images/fishers.jpg')	
# read input image -- (should be a color image)

HazeCorrected, hmap = image_dehazer.remove_haze(HImg, showHazeTransmissionMap=False)		# Remove Haze

cv2.imshow('hmap', hmap);						

# display the original hazy image
cv2.imshow('enhanced_image', HazeCorrected);			

# display the result
cv2.waitKey(0)
cv2.imwrite("outputImages/result.png", HazeCorrected)